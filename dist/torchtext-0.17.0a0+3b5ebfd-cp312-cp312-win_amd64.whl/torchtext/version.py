__version__ = '0.17.0a0+3b5ebfd'
git_version = '3b5ebfd14600ee48e015772064a02875e3468a19'
